#!/bin/sh

mkdir -p /mnt/system
mkdir -p /mnt/data
mkdir -p /mnt/backup

mount /dev/nvme0n1p6 /mnt/system
mount /dev/nvme0n1p7 /mnt/data
mount /dev/nvme0n1p8 /mnt/backup
